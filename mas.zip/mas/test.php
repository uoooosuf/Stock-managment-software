
<!DOCTYPE html>
<html>
<head>
	<title>test</title>
</head>
<body>
<?php 

$a = 2;
$b = 9;
$C = -18;

if($b < 1){

	echo "is = 0";


}else{
	echo "is not";
}

 ?>
</body>
</html>