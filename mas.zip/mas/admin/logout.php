
<?php 
require_once('conn.php');
require_once('functions.php');


logout();



 




 ?>

