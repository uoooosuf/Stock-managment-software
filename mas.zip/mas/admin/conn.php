<?php 	
 			session_start();
 			
	$conn = mysqli_connect('localhost', 'root', '', 'fcmt') or die('Cant Connect');

 ?>
      
       