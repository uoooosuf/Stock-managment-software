<?php 
require_once('conn.php');
require_once('functions.php');

if ($userId == 0) {

 header('location:index.php');

}
 ?>


<ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="home.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboad</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="refresh.php">
            <i class="fas fa-fw fa-copy"></i>
            <span> Refresh</span></a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="available.php">
            <i class="fas fa-fw fa-info"></i>
            <span> Availability</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="daily_r.php">
            <i class="fas fa-fw fa-history"></i>
            <span>Daily Report</span></a>
        </li>

         <li class="nav-item">
          <a class="nav-link" href="daily_history.php">
            <i class="fas fa-fw fa-history"></i>
            <span>Daily History</span></a>
        </li>


          <h6 class="dropdown-header">Admin Role</h6>
      
        <li class="nav-item">
          <a class="nav-link" href="add_stock.php">
            <i class="fas fa-fw fa-plus"></i>
            <span>Add Stock</span></a>
        </li>

         <li class="nav-item">
          <a class="nav-link" href="update_stock.php">
            <i class="fas fa-fw fa-clock"></i>
            <span>Update Stock</span></a>
        </li>


        <li class="nav-item ">
          <a class="nav-link" href="create_user.php">
            <i class="fas fa-fw fa-user"></i>
            <span>Create User</span></a>
        </li>

        
          <li class="nav-item">
          <a class="nav-link" href="history.php">
            <i class="fas fa-fw fa-table"></i>
            <span>History</span></a>
        </li>


      </ul>



      <div id="content-wrapper">

        